﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ExplorableAreas_By_MohamadNoghnogh
{
    class World
    {
        string Name = "Haunted Findings";
        List<Locations> Location;
        Person player;

        public World()
        {
            SetUpWorld();
            SetUpPlayer();
            LocationMenu();
        }

        private void SetUpWorld()
        {
            Location = new List<Locations>();

            Title = Name + " by Mohammad Noghnogh";
            WriteLine($"Welcome to " + Title);
            Person npc;

            //define npc (Person) for the haunted house
            String text = "Hi there. What brings you here?";
            npc = new Person(text);

            List<Items> temp = new List<Items>();
            temp.Add(new Items("Cup", "Regular cup"));
            temp.Add(new Items("Plate", "Dusty plate"));
            temp.Add(new Items("Rock", "Just a rock"));
            temp.Add(new Items("Coin", "Rare coin"));
            temp.Add(new Items("Mask", "Scary ghost mask"));
            Location.Add(new Locations("Haunted House", "People said it's haunted", temp, npc, ConsoleColor.Cyan));

            //define npc (Person) for the forbidden forest
            text = "Hello there. You looking for something?";
            npc = new Person(text);

            List<Items> temp2 = new List<Items>();
            temp2.Add(new Items("Leaf", "Regular leaf"));
            temp2.Add(new Items("Stick", "Ordinary stick"));
            temp2.Add(new Items("Mask", "Regular paintless mask"));
            temp2.Add(new Items("Recorder", "Tape recorder"));
            Location.Add(new Locations("Forbidden forest", "Scary forest", temp2, npc));

            //define npc (person) for the amusement park
            text = "Hey buddy, you lose something?";
            npc = new Person(text);

            List<Items> temp3 = new List<Items>();
            temp3.Add(new Items("Treasure", "Gold Jewels ETC."));
            Location.Add(new Locations("Abandoned amusement park", "Where it all leads up to", temp3, npc, ConsoleColor.DarkBlue));

        }

        private void SetUpPlayer()
        {
            WriteLine("What is your name?");
            string input = ReadLine();
            player = new Person(input, new List<Items>());

            WriteLine("Welcome " + player.Name + ", care to test your might on my latest contraption?");
        }

        private void LocationMenu()
        {
            WriteLine("Which will you choose");
            int choice = 1;
            foreach (Locations location in Location)
            {
                WriteLine(choice + ") " + location.About());
                choice++;
            }
            string input = ReadLine();
            switch (input)
            {
                case "1":
                    //0
                    Travel(0);
                    break;

                case "2":
                    //1
                    Travel(1);
                    break;

                case "3":
                    //2

                    bool mask = false;
                    bool Recorder = false;
                    bool Evidence = false;
                    foreach (Items item in player.Inventory)
                    {
                        if (item.Name.Contains("mask"))
                        {
                            mask = true;
                        }
                        else if (item.Name.Contains("recorder"))
                        {
                            Recorder = true;
                        }
                        else if (item.Name.Contains("evidence"))
                        {
                            Evidence = true;
                        }

                    }
                    if (mask && Recorder && Evidence)
                    { Travel(2); }
                    else
                    {
                        WriteLine("You don't have enough evidence to prove your case that there is no ghost. ");
                    }
                    break;
            }

            ReadKey();
            LocationMenu();
        }


        private void Travel(int choice)
        {

            BackgroundColor = Location[choice].LocationColor;
            ForegroundColor = ConsoleColor.White;
            Clear();
            WriteLine($"Welcome {player.Name} to {Location[choice].Name}");

            WriteLine(Location[choice].Desciption);


            Items randomItem = Location[choice].Items[Utility.GetRandomNumber(Location[choice].Items.Count)];
            WriteLine($"You see a {randomItem.Name} ({randomItem.Description}) lying on the ground. Do you pick it up?");
            string input = ReadLine();
            if (input.ToLower() == "yes")
            {
                player.Inventory.Add(randomItem);
            }

            //display message using that location's npc
            WriteLine("You see a " + Location[choice].NPC.Name);
            WriteLine(Location[choice].NPC.Name + ": " + Location[choice].NPC.text);

            WriteLine("Here's what you currently have right now:");
            foreach (Items item in player.Inventory)
            {
                WriteLine(item.Name);
            }

            WriteLine("Press any key to continue....");
            ReadKey();
        }
    }
}
