﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ExplorableAreas_By_MohamadNoghnogh
{
    class Locations
    {
        public string Name;
        public string Desciption;
        public List<Items> Items = new List<Items>();
        public ConsoleColor LocationColor = new ConsoleColor();
        public Person NPC;

        public Locations(string name, string description, List<Items> items, Person NPC)
        {
            Name = name;
            Desciption = description;
            Items = items;
            this.NPC = NPC;
            LocationColor = ConsoleColor.DarkGreen;
        }

        public Locations(string name, string description, List<Items> items, Person NPC, ConsoleColor color)
        {
            Name = name;
            Desciption = description;
            Items = items;
            this.NPC = NPC;
            LocationColor = color;
        }

        public string About()
        {
            return $"{Name}: {Desciption}";
        }
    }
}
