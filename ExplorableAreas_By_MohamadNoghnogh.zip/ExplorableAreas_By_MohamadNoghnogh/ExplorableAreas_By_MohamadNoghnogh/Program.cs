﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


/*
 * Explorable Areas by Mohamad Kaled Noghnogh
 * July 10th 2020
 * Assistance by Bassem Noghnogh
 */

namespace ExplorableAreas_By_MohamadNoghnogh
{
    class Program
    {
        static void Main(string[] args)
        {
            new World();
        }
    }
}
