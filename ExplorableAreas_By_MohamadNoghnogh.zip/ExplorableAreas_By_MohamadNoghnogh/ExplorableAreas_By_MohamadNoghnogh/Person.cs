﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplorableAreas_By_MohamadNoghnogh
{
    class Person
    {
        public string Name;
        public List<Items> Inventory;
        public string text;

        public Person(string name, List<Items> inventory)
        {
            if (name != "")
            { 
                Name = name; 
            }
            else
            { 
                Name = "Nameless Explorer"; 
            }
            Inventory = inventory;
        }

        public Person(string text)
        {
            Name = "Nameless Person";
            this.text = text;
        }
    }
}
