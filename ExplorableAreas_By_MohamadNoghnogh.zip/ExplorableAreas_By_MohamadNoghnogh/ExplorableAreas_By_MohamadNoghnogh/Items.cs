﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ExplorableAreas_By_MohamadNoghnogh
{
    class Items
    {
        public string Name;
        public string Description;

        public Items(string name, string description)
        {
            Name = name;
            Description = description;
        }
    }
}
